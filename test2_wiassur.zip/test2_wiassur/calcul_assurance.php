<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ageConducteur = isset($_POST['age']) ? intval($_POST['age']) : 0;
    $modeleVoiture = isset($_POST['modele']) ? $_POST['modele'] : '';

    // Logique de calcul de l'assurance (ex. utilisation de coefficients arbitraires)
    $coeff_age = 50;
    $coeff_modele = 100;

    // Calcul du coût de l'assurance
    $coutAssurance = $ageConducteur * $coeff_age + strlen($modeleVoiture) * $coeff_modele;

    // Renvoyer la réponse en format JSON
    $response = array(
        'coutAssurance' => $coutAssurance
    );

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
