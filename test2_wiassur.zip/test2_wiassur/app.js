// Données des tâches (exemple)
const tasksData = [
  { title: 'Acheter des courses', description: 'Aller au supermarché et acheter des courses pour la semaine', status: 'A faire' },
  { title: 'Répondre aux e-mails', description: 'Répondre aux e-mails importants reçus hier', status: 'En cours' },
  { title: 'Préparer la réunion', description: 'Préparer les documents et les présentations pour la réunion de demain', status: 'Terminée' }
];

// Vue.js
const app = new Vue({
  el: '#app',
  data: {
    tasks: tasksData
  },
  methods: {
    // Fonction pour marquer une tâche comme accomplie
    markAsCompleted(index) {
      this.tasks[index].status = 'Terminée';
    },
    // Fonction pour supprimer une tâche
    deleteTask(index) {
      this.tasks.splice(index, 1);
    }
  }
});
