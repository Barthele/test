document.addEventListener('DOMContentLoaded', () => {
  const assuranceForm = document.getElementById('assuranceForm');
  const calculerBtn = document.getElementById('calculerBtn');
  const resultatDiv = document.getElementById('resultat');
  const resultatMarque = document.getElementById('resultat_marque');
  const resultatModele = document.getElementById('resultat_modele');
  const resultatCout = document.getElementById('resultat_cout');

  calculerBtn.addEventListener('click', () => {
    const formData = new FormData(assuranceForm);

    fetch('calcul_assurance.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      resultatMarque.textContent = formData.get('marque');
      resultatModele.textContent = formData.get('modele');
      resultatCout.textContent = data.coutAssurance;
      resultatDiv.classList.remove('hidden');
    })
    .catch(error => console.error('Erreur lors de la requête :', error));
  });
});
